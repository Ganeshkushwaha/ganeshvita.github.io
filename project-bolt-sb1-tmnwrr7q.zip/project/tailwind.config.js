/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        background: '#525252',
        // Primary Colors
        primary: {
          DEFAULT: '#F8F9FA', // Light gray for contrast
          light: '#E9ECEF', // Lighter shade
        },
        // Secondary/Accent Colors
        accent: {
          DEFAULT: '#FFD700', // Gold
          light: '#FFF4B8', // Light gold
        },
        // Neutral Colors
        neutral: {
          50: '#F8F9FA',
          100: '#E9ECEF',
          200: '#DEE2E6',
          300: '#CED4DA',
          400: '#ADB5BD',
          500: '#6C757D',
          600: '#495057',
          700: '#343A40',
          800: '#212529',
          900: '#121416',
        }
      },
      fontFamily: {
        sans: ['Inter', 'sans-serif'],
        display: ['Playfair Display', 'serif'],
      },
      spacing: {
        '18': '4.5rem',
        '88': '22rem',
      },
    },
  },
  plugins: [],
};