import React from 'react';
import { Camera, Video, Award } from 'lucide-react';

const About = () => {
  return (
    <section id="about" className="py-20">
      <div className="container mx-auto px-6">
        <div className="backdrop-blur-md bg-white/30 rounded-2xl shadow-lg p-8 md:p-12">
          <h2 className="text-4xl font-bold text-gray-800 mb-8 text-center">About Me</h2>
          
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <img
                src="https://images.unsplash.com/photo-1554151228-14d9def656e4?auto=format&fit=crop&q=80&w=800"
                alt="Profile"
                className="rounded-xl shadow-lg w-full h-96 object-cover"
              />
            </div>
            
            <div className="space-y-6">
              <p className="text-lg text-gray-700">
                I'm a passionate photographer and video editor with over 5 years of experience
                capturing life's most beautiful moments. My work focuses on finding the extraordinary
                in the ordinary, whether through portrait photography or cinematic storytelling.
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="backdrop-blur-md bg-white/20 p-6 rounded-xl">
                  <Camera className="w-8 h-8 mb-4 text-gray-800" />
                  <h3 className="text-xl font-semibold mb-2">Photography</h3>
                  <p className="text-gray-700">Specializing in portraits and landscapes</p>
                </div>
                
                <div className="backdrop-blur-md bg-white/20 p-6 rounded-xl">
                  <Video className="w-8 h-8 mb-4 text-gray-800" />
                  <h3 className="text-xl font-semibold mb-2">Videography</h3>
                  <p className="text-gray-700">Creating compelling visual stories</p>
                </div>
              </div>

              <div className="flex items-center space-x-4 mt-8">
                <Award className="w-6 h-6 text-gray-800" />
                <span className="text-gray-700">Multiple awards for excellence in visual arts</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;