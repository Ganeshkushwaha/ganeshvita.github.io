import React, { useState, useEffect } from 'react';
import { Menu, X, ChevronUp } from 'lucide-react';

const Navigation = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [showScrollTop, setShowScrollTop] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 300);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const menuItems = [
    { title: 'Home', href: '#home' },
    { title: 'Gallery', href: '#gallery' },
    { title: 'Videos', href: '#videos' },
    { title: 'About', href: '#about' },
    { title: 'Contact', href: '#contact' },
  ];

  return (
    <>
      <nav className="fixed w-full z-50 px-6 py-4">
        <div className="backdrop-blur-md bg-white/30 rounded-2xl shadow-lg px-6 py-4">
          <div className="flex justify-between items-center">
            <a href="#home" className="text-2xl font-bold text-gray-500">
              GANESHvita
            </a>
            
            <div className="hidden md:flex space-x-8">
              {menuItems.map((item) => (
                <a
                  key={item.title}
                  href={item.href}
                  className="text-gray-800 hover:text-gray-600 transition-colors"
                >
                  {item.title}
                </a>
              ))}
            </div>

            <button
              className="md:hidden"
              onClick={() => setIsOpen(!isOpen)}
            >
              {isOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>

          {isOpen && (
            <div className="md:hidden mt-4 space-y-4">
              {menuItems.map((item) => (
                <a
                  key={item.title}
                  href={item.href}
                  className="block text-gray-800 hover:text-gray-600 transition-colors"
                  onClick={() => setIsOpen(false)}
                >
                  {item.title}
                </a>
              ))}
            </div>
          )}
        </div>
      </nav>

      {showScrollTop && (
        <button
          onClick={scrollToTop}
          className="fixed bottom-8 right-8 p-3 backdrop-blur-md bg-white/30 rounded-full shadow-lg hover:bg-white/50 transition-all z-50"
        >
          <ChevronUp size={24} />
        </button>
      )}
    </>
  );
};

export default Navigation;