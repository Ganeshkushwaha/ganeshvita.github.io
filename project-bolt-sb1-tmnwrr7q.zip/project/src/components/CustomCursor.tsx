import React, { useEffect, useState } from 'react';

const CustomCursor = () => {
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [isHovering, setIsHovering] = useState(false);

  useEffect(() => {
    const updateCursor = (e: MouseEvent) => {
      setPosition({ x: e.clientX, y: e.clientY });
    };

    const updateHoverState = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      setIsHovering(
        target.tagName === 'BUTTON' || 
        target.tagName === 'A' || 
        target.closest('button') !== null || 
        target.closest('a') !== null
      );
    };

    document.addEventListener('mousemove', updateCursor);
    document.addEventListener('mouseover', updateHoverState);

    return () => {
      document.removeEventListener('mousemove', updateCursor);
      document.removeEventListener('mouseover', updateHoverState);
    };
  }, []);

  return (
    <>
      <div
        className="fixed w-4 h-4 bg-white rounded-full mix-blend-difference pointer-events-none z-50
                   transform -translate-x-1/2 -translate-y-1/2 transition-transform duration-100"
        style={{
          left: `${position.x}px`,
          top: `${position.y}px`,
          transform: `translate(-50%, -50%) scale(${isHovering ? 2.5 : 2})`
        }}
      />
      <div
        className="fixed w-8 h-8 border border-white rounded-full mix-blend-difference pointer-events-none z-50
                   transform -translate-x-1/2 -translate-y-1/2 transition-transform duration-300"
        style={{
          left: `${position.x}px`,
          top: `${position.y}px`,
          transform: `translate(-50%, -50%) scale(${isHovering ? 3 : 5})`
        }}
      />
    </>
  );
};

export default CustomCursor;