import React from 'react';
import { Play } from 'lucide-react';

const videos = [
  {
    id: 1,
    title: 'Cinematic Nature',
    thumbnail: 'https://images.unsplash.com/photo-1518156677180-95a2893f3e9f?auto=format&fit=crop&q=80&w=800',
    embedId: 'dQw4w9WgXcQ'
  },
  {
    id: 2,
    title: 'Urban Stories',
    thumbnail: 'https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?auto=format&fit=crop&q=80&w=800',
    embedId: 'dQw4w9WgXcQ'
  },
  {
    id: 3,
    title: 'Portrait Series',
    thumbnail: 'https://images.unsplash.com/photo-1494022299300-899b96e49893?auto=format&fit=crop&q=80&w=800',
    embedId: 'dQw4w9WgXcQ'
  }
];

const VideoShowcase = () => {
  return (
    <section id="videos" className="py-20 bg-gray-50">
      <div className="container mx-auto px-6">
        <h2 className="text-4xl font-bold text-gray-800 mb-12 text-center">Video Projects</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {videos.map(video => (
            <div
              key={video.id}
              className="group relative overflow-hidden rounded-xl shadow-lg transition-transform hover:scale-105"
            >
              <img
                src={video.thumbnail}
                alt={video.title}
                className="w-full h-64 object-cover"
                loading="lazy"
              />
              <div className="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity">
                <div className="p-4 backdrop-blur-md bg-white/30 rounded-full">
                  <Play size={32} className="text-white" />
                </div>
                <div className="absolute bottom-0 left-0 right-0 p-6 backdrop-blur-md bg-white/30">
                  <h3 className="text-white text-xl font-semibold">{video.title}</h3>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default VideoShowcase;