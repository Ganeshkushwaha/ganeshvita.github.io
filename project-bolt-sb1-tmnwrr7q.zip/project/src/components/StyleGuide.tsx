import React from 'react';

const StyleGuide = () => {
  return (
    <div className="container mx-auto px-6 py-12">
      <h1 className="heading-1 mb-12">Style Guide</h1>
      
      {/* Colors */}
      <section className="mb-12">
        <h2 className="heading-2 mb-6">Colors</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          <div>
            <div className="h-24 bg-primary rounded-lg mb-2"></div>
            <p className="font-mono text-sm">Primary: #2A4365</p>
          </div>
          <div>
            <div className="h-24 bg-primary-light rounded-lg mb-2"></div>
            <p className="font-mono text-sm">Primary Light: #3B82F6</p>
          </div>
          <div>
            <div className="h-24 bg-accent rounded-lg mb-2"></div>
            <p className="font-mono text-sm">Accent: #D97706</p>
          </div>
          <div>
            <div className="h-24 bg-accent-light rounded-lg mb-2"></div>
            <p className="font-mono text-sm">Accent Light: #FBBF24</p>
          </div>
        </div>
      </section>

      {/* Typography */}
      <section className="mb-12">
        <h2 className="heading-2 mb-6">Typography</h2>
        <div className="space-y-6">
          <div>
            <h1 className="heading-1">Heading 1 - Playfair Display Bold 64px/48px</h1>
            <p className="font-mono text-sm text-neutral-500 mt-2">font-display text-7xl font-bold</p>
          </div>
          <div>
            <h2 className="heading-2">Heading 2 - Playfair Display SemiBold 36px/28px</h2>
            <p className="font-mono text-sm text-neutral-500 mt-2">font-display text-4xl font-semibold</p>
          </div>
          <div>
            <h3 className="heading-3">Heading 3 - Playfair Display SemiBold 24px/20px</h3>
            <p className="font-mono text-sm text-neutral-500 mt-2">font-display text-2xl font-semibold</p>
          </div>
          <div>
            <p className="body-large">Body Large - Inter Regular 18px/28px</p>
            <p className="font-mono text-sm text-neutral-500 mt-2">font-sans text-lg leading-relaxed</p>
          </div>
          <div>
            <p className="body-base">Body Base - Inter Regular 16px/24px</p>
            <p className="font-mono text-sm text-neutral-500 mt-2">font-sans text-base leading-relaxed</p>
          </div>
        </div>
      </section>

      {/* Components */}
      <section className="mb-12">
        <h2 className="heading-2 mb-6">Components</h2>
        <div className="space-y-6">
          <div className="space-x-4">
            <button className="btn-primary">Primary Button</button>
            <button className="btn-secondary">Secondary Button</button>
          </div>
          <div className="max-w-md">
            <div className="glass-card">
              <h3 className="heading-3 mb-4">Glass Card</h3>
              <p className="body-base">Content with backdrop blur effect</p>
            </div>
          </div>
          <div className="max-w-md space-y-4">
            <input type="text" className="input-field" placeholder="Input Field" />
            <select className="input-field">
              <option>Select Option</option>
            </select>
          </div>
        </div>
      </section>

      {/* Spacing */}
      <section>
        <h2 className="heading-2 mb-6">Spacing System</h2>
        <div className="space-y-4">
          <div className="flex items-center space-x-4">
            <div className="w-4 h-4 bg-primary"></div>
            <span className="font-mono text-sm">4 - 1rem (16px)</span>
          </div>
          <div className="flex items-center space-x-4">
            <div className="w-6 h-6 bg-primary"></div>
            <span className="font-mono text-sm">6 - 1.5rem (24px)</span>
          </div>
          <div className="flex items-center space-x-4">
            <div className="w-8 h-8 bg-primary"></div>
            <span className="font-mono text-sm">8 - 2rem (32px)</span>
          </div>
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 bg-primary"></div>
            <span className="font-mono text-sm">12 - 3rem (48px)</span>
          </div>
        </div>
      </section>
    </div>
  );
};

export default StyleGuide;