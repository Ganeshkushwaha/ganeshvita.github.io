import React, { useState } from 'react';

const categories = ['All', 'Portrait', 'Landscape', 'Street', 'Architecture'];

const photos = [
  {
    id: 1,
    category: 'Portrait',
    url: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=800',
    title: 'Portrait Study'
  },
  {
    id: 2,
    category: 'Landscape',
    url: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&q=80&w=800',
    title: 'Mountain Vista'
  },
  {
    id: 3,
    category: 'Street',
    url: 'https://images.unsplash.com/photo-1519575706483-221027bfbb31?auto=format&fit=crop&q=80&w=800',
    title: 'Urban Life'
  },
  {
    id: 4,
    category: 'Architecture',
    url: 'https://images.unsplash.com/photo-1511818966892-d7d671e672a2?auto=format&fit=crop&q=80&w=800',
    title: 'Modern Lines'
  },
  {
    id: 5,
    category: 'Portrait',
    url: 'https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?auto=format&fit=crop&q=80&w=800',
    title: 'Natural Light'
  },
  {
    id: 6,
    category: 'Landscape',
    url: 'https://images.unsplash.com/photo-1505159940484-eb2b9f2588e2?auto=format&fit=crop&q=80&w=800',
    title: 'Coastal Dreams'
  }
];

const Gallery = () => {
  const [activeCategory, setActiveCategory] = useState('All');

  const filteredPhotos = activeCategory === 'All'
    ? photos
    : photos.filter(photo => photo.category === activeCategory);

  return (
    <section id="gallery" className="py-20">
      <div className="container mx-auto px-6">
        <h2 className="text-4xl font-bold text-gray-800 mb-12 text-center">Photography Portfolio</h2>
        
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {categories.map(category => (
            <button
              key={category}
              onClick={() => setActiveCategory(category)}
              className={`px-6 py-2 rounded-full backdrop-blur-md transition-all
                ${activeCategory === category 
                  ? 'bg-white/50 shadow-lg' 
                  : 'bg-white/30 hover:bg-white/40'}`}
            >
              {category}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredPhotos.map(photo => (
            <div
              key={photo.id}
              className="group relative overflow-hidden rounded-xl shadow-lg transition-transform hover:scale-105"
            >
              <img
                src={photo.url}
                alt={photo.title}
                className="w-full h-80 object-cover"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity">
                <div className="absolute bottom-0 left-0 right-0 p-6 backdrop-blur-md bg-white/30">
                  <h3 className="text-white text-xl font-semibold">{photo.title}</h3>
                  <p className="text-white/80">{photo.category}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Gallery;