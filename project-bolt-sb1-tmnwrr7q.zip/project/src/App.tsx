import React from 'react';
import Navigation from './components/Navigation';
import Gallery from './components/Gallery';
import VideoShowcase from './components/VideoShowcase';
import About from './components/About';
import Contact from './components/Contact';
import ImageSlider from './components/ImageSlider';
import CustomCursor from './components/CustomCursor';

function App() {
  return (
    <div className="min-h-screen bg-background">
      <CustomCursor />
      <Navigation />
      
      <main className="pt-24">
        <section id="home" className="relative min-h-screen flex items-center justify-center px-6">
          <ImageSlider />
          <div className="relative z-20 text-center space-y-12">
            <h1 className="heading-1">
              Capturing<br />Moments
            </h1>
            <p className="body-large max-w-2xl mx-auto">
              Professional photography and video editing services that bring your vision to life
            </p>
            <a href="#gallery" className="btn-primary inline-block">
              View Portfolio
            </a>
          </div>
        </section>

        <Gallery />
        <VideoShowcase />
        <About />
        <Contact />
      </main>

      <footer className="bg-background/50 backdrop-blur-md border-t border-white/10 py-8 mt-20">
        <div className="container mx-auto px-6 text-center">
          <p className="text-primary-light/70">&copy; 2025 Photography Portfolio. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

export default App;